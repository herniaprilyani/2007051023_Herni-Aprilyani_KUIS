/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author user
 */
public class Cpu {
    private String id;
    private String merek;
    private String tanggal;
    private String harga;
    private String warna;

    public Cpu(String id, String merek, String tanggal, String harga, String warna) {
        this.id = id;
        this.merek = merek;
        this.tanggal = tanggal;
        this.harga = harga;
        this.warna = warna;
    }

    public String getid() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMerek() {
        return merek;
    }

    public void setMerk(String merek) {
        this.merek = merek;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggalProduksi(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public String getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    

    
}
