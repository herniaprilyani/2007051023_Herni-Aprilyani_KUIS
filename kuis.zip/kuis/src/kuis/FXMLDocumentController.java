/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis;

import database.dbHelper;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import model.Cpu;

/**
 *
 * @author user
 */
public class FXMLDocumentController implements Initializable {
    
    
    @FXML
    private Label label;

    @FXML
    private TextField textId;

    @FXML
    private TextField textMerek;

    @FXML
    private TextField textHarga;

    @FXML
    private MenuButton textWarna;

    @FXML
    private DatePicker date;
    
    @FXML

    private void handleButtonAction(ActionEvent event) {
       
        System.out.println(textId.getText());
        System.out.println(textMerek.getText());
        System.out.println(textHarga.getText());
        System.out.println(textWarna.toString());
        System.out.println(date.getValue().toString());
        Cpu cpup = new Cpu(textId.getText(),textMerek.getText(),textHarga.getText(),date.getValue().toString(),textWarna.toString());
        dbHelper dh = new dbHelper("MYSQL");
        dh.addCPU(cpup);
       
         }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ArrayList <String> list = new ArrayList<>();
            list.add("Hitam");
            list.add("Biru");
            list.add("Merah");
        ObservableList items = FXCollections.observableArrayList(list);
        textWarna.setMnu(menu);
    }    
}
