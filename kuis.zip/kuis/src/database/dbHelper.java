/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cpu;

public class dbHelper {
    public final Connection conn;

    public dbHelper(String driver) {
        this.conn = database.getConnection(driver);
    }
    public void addCPU(Cpu cpup){
        String insertCpup = "INSERT INTO `datacpu`(`id`, `merek`,`warna`,`harga`,`tanggal`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertCpup);
            stmtInsert.setString(1, cpup.getId());
            stmtInsert.setString(2, cpup.getMerek());
            stmtInsert.setString(3, cpup.getWarna());
            stmtInsert.setString(4, cpup.getHarga());
            stmtInsert.setString(5, cpup.getTanggal());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}